<?php
    define('DB_NAME', 'harshith_hoth');
    define('DB_USER', 'harshith_hothuser');
    define('DB_PASSWORD', 'dCE0%WpV4kCB');
    define('DB_HOST', 'localhost');
?>